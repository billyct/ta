<?php

namespace TA;

class OAuthException extends \Exception {
}

?>