
The repository of SeaJS modules.

http://modules.seajs.org/

http://modules.seajs.org/test.html


For Advanced Users
------------------

Update xxx module:

````
spm transport xxx --force
````

Update registry.js:

````
node update_all.js
````
