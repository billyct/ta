/**
 * ta的配置文件
 */

exports.config = {
	name: 'ta',
	description: 'ta',
	host: '127.0.0.1',
	port: 1337,
	version: '0.0.1'

};
