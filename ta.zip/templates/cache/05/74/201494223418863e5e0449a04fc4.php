<?php

/* timeline/timeline-sidebar.html */
class __TwigTemplate_0574201494223418863e5e0449a04fc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo " <div class=\"page-sidebar\">
    <ul>
    \t<li><a href=\"\"><i class=\"icon-home\"></i>首页</a></li>
        <li class=\"sticker sticker-color-blue dropdown active\" data-role=\"dropdown\">
        \t<a href=\"javascript:void(0);\"><i class=\"icon-reddit\"></i>我的</a>
        \t<ul class=\"sub-menu sidebar-dropdown-menu light open\">
        \t\t<li><a href=\"#\">消息</a></li>
        \t\t<li><a href=\"\">主页</a></li>
        \t\t<li><a href=\"\">收藏</a></li>
        \t</ul>
        </li>
    </ul>
</div>
";
    }

    public function getTemplateName()
    {
        return "timeline/timeline-sidebar.html";
    }

    public function getDebugInfo()
    {
        return array (  234 => 96,  210 => 74,  198 => 67,  191 => 65,  188 => 64,  182 => 62,  174 => 61,  171 => 60,  164 => 58,  161 => 57,  148 => 54,  144 => 52,  137 => 50,  134 => 49,  128 => 47,  120 => 46,  111 => 44,  103 => 43,  99 => 41,  88 => 37,  84 => 35,  79 => 34,  71 => 30,  62 => 28,  54 => 24,  46 => 18,  41 => 17,  31 => 10,  19 => 1,);
    }
}
