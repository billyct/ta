<?php

/* cny15/sidebar.html */
class __TwigTemplate_694f1ac3df09999d57f1b974ad8fbb6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo " <div class=\"page-sidebar\">
    <ul>
    \t<li><a href=\"";
        // line 3
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15\"><i class=\"icon-home\"></i>首页</a></li>

        <li class=\"sticker sticker-color-blue dropdown active\">
        \t<a href=\"javascript:void(0);\"><i class=\"icon-reddit\"></i>个人中心</a>
        \t<ul class=\"sub-menu light\">
        \t\t<li><a href=\"#\">消息</a></li>
        \t\t<li><a href=\"\">主页</a></li>
        \t\t<li><a href=\"\">收藏</a></li>
        \t</ul>
        </li>
        
        <li class=\"sticker sticker-color-green\">
        \t<a href=\"javascript:void(0);\"><i class=\"icon-user-3\"></i>我是卖家</a>
        \t<ul class=\"sub-menu light open\">
                <li><a href=\"";
        // line 17
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15/manage/new\">发布￥15</a></li>
        \t\t<li><a href=\"";
        // line 18
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15/manage\">我的￥15</a></li>
        \t\t<li><a href=\"";
        // line 19
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15/manage/my_sell_order\">订单管理</a></li>
        \t\t<li><a href=\"";
        // line 20
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15/manage/income\">收入管理</a></li>
        \t</ul>
        </li>
        <li class=\"sticker sticker-color-yellow\">
        \t<a href=\"\"><i class=\"icon-cart\"></i>我是买家</a>
            <ul class=\"sub-menu light\">
                <li><a href=\"";
        // line 26
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "/cny15/manage/my_buy_order\">我的订单</a></li>
            </ul>
        </li>
    </ul>
</div>";
    }

    public function getTemplateName()
    {
        return "cny15/sidebar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 26,  56 => 20,  51 => 19,  46 => 18,  41 => 17,  23 => 3,  19 => 1,);
    }
}
