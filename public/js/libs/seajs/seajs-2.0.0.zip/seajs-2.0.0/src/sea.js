var seajs = global.seajs = {
  // The current version of SeaJS being used
  version: "@VERSION"
}

