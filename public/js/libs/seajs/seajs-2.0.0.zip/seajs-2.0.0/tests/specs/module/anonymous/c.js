define({ name: 'c0' });
define('./anonymous/c.js', [], { name: 'c' });
define('./anonymous/c2.js', [], { name: 'c2' });
