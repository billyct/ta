define(function() {

  return {
    foo: 'c'
  }

});
