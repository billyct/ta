
seajs.config({
  plugins: ["warning"]
})

seajs.use("./plugin-warning/init")

