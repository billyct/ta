define('b', [], { name: 'b' })
define('c', [], { name: 'c' })
define('d', [], { name: 'd' })
