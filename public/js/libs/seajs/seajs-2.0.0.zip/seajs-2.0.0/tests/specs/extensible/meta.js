define([
  'backbone-shim',
  'combo-map',
  'module-constructor',
  'mutable-shim',
  'non-cmd',
  'plugin-combo',
  'plugin-nocache',
  'plugin-shim',
  'plugin-text',
  'plugin-warning'
])

