define(function(require, exports) {
  exports.name = 'c'
  exports.d = require('./d')
  exports.a = require('./a')
});

