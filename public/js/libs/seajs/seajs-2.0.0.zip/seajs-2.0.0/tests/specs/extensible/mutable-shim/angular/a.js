
jQuery.a = 'a'
