
Array.prototype.map = Array.prototype.map || { fake: true };
