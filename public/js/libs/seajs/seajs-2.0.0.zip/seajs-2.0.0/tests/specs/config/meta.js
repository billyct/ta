define([
  'alias',
  'base',
  'charset',
  'debug',
  'hasOwnProperty',
  'map',
  'paths',
  'preload',
  'vars'
])

