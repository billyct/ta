global.g_destroy++

define({ name: 'a' + global.g_destroy })
