

global.Backbone = { name: 'backbone', _: _ }
