define('long/4', [], { name: '4' })
define('long/5', [], { name: '5' })
define('long/6', [], { name: '6' })
