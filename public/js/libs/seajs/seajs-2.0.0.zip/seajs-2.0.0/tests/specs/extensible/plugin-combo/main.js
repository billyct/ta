
seajs.config({
  base: "./plugin-combo/",
  test: true,
  plugins: ["combo"]
})

seajs.use("init")

