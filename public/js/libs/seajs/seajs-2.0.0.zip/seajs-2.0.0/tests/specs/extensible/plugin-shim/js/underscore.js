
global._ = { name: 'underscore' }
