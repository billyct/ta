
jQuery.b = 'b'
