define(function(require, exports) {
  exports.name = 'e'
  exports.a = require('./a')
  exports.c = require('./c')
});


