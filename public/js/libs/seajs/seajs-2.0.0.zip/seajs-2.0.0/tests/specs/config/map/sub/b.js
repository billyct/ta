define({ name: 'b' })
