define(function (require, exports) {

  exports.mainExports = function () {
    return require('./main')
  }

});
