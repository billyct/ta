
seajs.config({
  alias: {
    'jquery': 'gallery/jquery/1.8.2/jquery.js'
  },

  paths: {
    'gallery': 'https://a.alipayobjects.com/gallery'
  }
})
